package com.example.reto3faom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto3faomApplication {

    public static void main(String[] args) {
        SpringApplication.run(Reto3faomApplication.class, args);
    }

}
