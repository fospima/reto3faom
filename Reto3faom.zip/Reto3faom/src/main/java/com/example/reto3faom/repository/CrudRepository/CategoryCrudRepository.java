package com.example.reto3faom.repository.CrudRepository;

import com.example.reto3faom.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category,Integer> {
}
