package com.example.reto3faom.repository.CrudRepository;


import com.example.reto3faom.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client,Integer> {
}
