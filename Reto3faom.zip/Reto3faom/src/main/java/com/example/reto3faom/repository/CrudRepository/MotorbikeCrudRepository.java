package com.example.reto3faom.repository.CrudRepository;

import com.example.reto3faom.model.Motorbike;
import org.springframework.data.repository.CrudRepository;

public interface MotorbikeCrudRepository extends CrudRepository<Motorbike,Integer> {
}
