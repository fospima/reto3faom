package com.example.reto3faom.repository.CrudRepository;


import com.example.reto3faom.model.Reservation;
import org.springframework.data.repository.CrudRepository;

public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {
}
