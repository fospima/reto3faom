package com.example.reto3faom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3faomApplicationTests {

    @Test
    void contextLoads() {
    }

}
